#Aquaponics Manager

Program for reading sensors and managing lights and other components for aquaponics system

System will be built focusing on a Reaspberry PI

Software will be Python3, focusing on I2C communication


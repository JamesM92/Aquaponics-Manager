#!/bin/bash

#main executable of program